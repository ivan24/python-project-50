from gendiff.cli import gendiff_parser


def main():
    gendiff_parser()


if __name__ == 'main':
    main()
